<!-- Modal -->
<div class="c-modal c-modal--xsmedium modal fade" id="modalgetjavascript" tabindex="-1" role="dialog" aria-labelledby="modalgetjavascript">
    <div class="c-modal__dialog modal-dialog" role="document">
        <div class="c-modal__content">
            <div class="c-modal__header">
            <h3 class="c-modal__title">Javascript</h3>
                <span class="c-modal__close" data-dismiss="modal" aria-label="Close">
                    <i class="fa fa-close"></i>
                </span>
            </div>
            <div class="c-modal__body">      
                <div class="c-field u-mb-small">
                    <input onclick="this.select()" readonly="" id='getjavascriptinput' name="javascript" class="c-input" type="text" placeholder="">
                </div>
            </div>
        </div><!-- // .c-modal__content -->
    </div><!-- // .c-modal__dialog -->
</div><!-- // .c-modal -->