<div class="col-md-12">
<div class="c-alert c-alert--info u-mb-medium">
<i class="c-alert__icon fa fa-check-circle"></i> Selamat Datang di <?= $settings['title']; ?> !
</div>

<div class="c-card c-card--responsive u-mb-medium">
<div class="c-card__header c-card__header--transparent o-line">
<h5 class="c-card__title">Dashboard</h5>
</div>
<div class="c-card__body">
<pre><code>&lt;div id=&apos;HTML303&apos;&gt;
testcoded&lt;/div&gt;
&lt;script src=&apos;http://script.kurteyki.com/activate/script.js&apos;&gt;&lt;/script&gt;</code></pre>
</div>
</div>

<div class="c-card c-card--responsive u-mb-medium">
<div class="c-card__header c-card__header--transparent o-line">
<h5 class="c-card__title">Dashboard</h5>
</div>
<div class="c-card__body">
<pre><code>&lt;div id=&apos;HTML303&apos;&gt;testcoded&lt;/div&gt;
&lt;script type=&quot;text/javascript&quot;&gt;
//&lt;![CDATA[
function removeElement(element) {
element &amp;&amp; element.parentNode &amp;&amp; element.parentNode.removeChild(element);
}	
(function () {    
var loadjs = document.createElement(&quot;script&quot;);
loadjs.type = &apos;text/javascript&apos;
loadjs.src = &quot;//script.kurteyki.com/activate/script.js&quot;;
loadjs.id = &quot;scriptlicense&quot;;     
loadjs.onload = function(){
removeElement(document.getElementById(&quot;scriptlicense&quot;));
};
(document.getElementsByTagName(&quot;head&quot;)[0] || document.getElementsByTagName(&quot;body&quot;)[0]).appendChild(loadjs);      
})();

document.onreadystatechange = function(){
if(document.readyState === &apos;complete&apos;){		
// Your Code Run After Load JS
}
}	
//]]&gt;
&lt;/script&gt;</code></pre>
</div>
</div>

</div><!-- col-md-12 -->