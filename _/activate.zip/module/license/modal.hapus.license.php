<!-- Modal -->
<div class="c-modal c-modal--xsmall modal fade" id="modalhapus" tabindex="-1" role="dialog" aria-labelledby="modalhapus">
    <div class="c-modal__dialog modal-dialog" role="document">
        <div class="c-modal__content">
            <div class="c-modal__header">
                <h3 class="c-modal__title">Konfirmasi Penghapusan</h3>
                <span class="c-modal__close" data-dismiss="modal" aria-label="Close">
                    <i class="fa fa-close"></i>
                </span>
            </div>
            <div class="c-modal__body">
                <a class="c-btn c-btn--danger c-btn--small" id="hapusurl">Hapus</a>
                <button class="c-btn c-btn--info c-btn--small" data-dismiss="modal">
                    Batal
                </button>
            </div>
        </div><!-- // .c-modal__content -->
    </div><!-- // .c-modal__dialog -->
</div><!-- // .c-modal -->