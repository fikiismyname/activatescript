<!-- Modal -->
<div class="c-modal c-modal--xsmall modal fade" id="modalupdate" tabindex="-1" role="dialog" aria-labelledby="modalupdate">
    <div class="c-modal__dialog modal-dialog" role="document">
        <div class="c-modal__content">
            <div class="c-modal__header">
                <h3 class="c-modal__title">Update License</h3>
                <span class="c-modal__close" data-dismiss="modal" aria-label="Close">
                    <i class="fa fa-close"></i>
                </span>
            </div>
            <div class="c-modal__body">
                <form method="POST" id="formupdate">            
                   <input name="id" class="c-input" type="hidden" value="" />                  
                   <div class="c-field u-mb-small">
                    <label class="c-field__label">Domain with out protocol (ex : kurteyki.com)</label>
                    <input name="domain" class="c-input" type="text" placeholder="">
                </div>
                <div class="c-field u-mb-xsmall">
                    <label class="c-field__label" for="updatetemplate">License to Template</label>
                    <!-- Select2 jquery plugin is used -->
                    <select name="template" class="c-select" id="updatetemplate" placeholder='Pilih'>
                        <?php  
                        $sql = "SELECT id,template FROM tb_template";
                        $result = $mysql->query($sql);
                        if ($result->num_rows == 0) {
                            sweetalert('Isi Data template Terlebih dahulu, data masih kosong !','error');        
                            header("Location: ./?module=template");
                            exit;
                        }
                        ?>
                        <?php
                        while ($read = $result->fetch_array()) {
                          if (empty($_SESSION['akses'])){
                            echo "<option value='".$read['id']."'>".$read['template']."</option>";
                        }else {     
                            foreach ($extractakses as $key => $value) {
                                if ($value == $read['id']) {
                                    echo "<option value='".$read['id']."'>".$read['template']."</option>";
                                }
                            }                           
                        }
                    }
                    ?>
                </select>
            </div>            
            <button class="c-btn c-btn--success" name="update" type="submit">
                Update License
            </button>
        </form>
    </div>
</div><!-- // .c-modal__content -->
</div><!-- // .c-modal__dialog -->
</div><!-- // .c-modal -->