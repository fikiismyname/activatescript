<?php  
switch (@$_GET['module']) {

	case 'user':
	include "module/user/index.php";
	break;

	case 'license':
	include "module/license/index.php";
	break;

	case 'template':
	include "module/template/index.php";
	break;

	case 'tentangaplikasi':
	include "module/tentangaplikasi/index.php";
	break;

	case 'userinfo':
	include "module/userinfo/index.php";
	break;

	default:
	include "module/dashboard/index.php";
	break;
	
}
?>