<a class="c-notification dropdown-toggle" href="javascript:;" id="dropdownMenuAlerts" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="c-notification__icon">
        <i class="fa fa-bell-o"></i>
    </span>
  <!--   <span class="c-notification__number">0</span> -->
</a>

<div class="c-dropdown__menu c-dropdown__menu--large dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuAlerts">
    <a href="javascript:;" class="c-dropdown__item dropdown-item o-media">
        <span class="o-media__img u-mr-xsmall">
            <span class="c-avatar c-avatar--xsmall">
                <span class="c-avatar__img u-bg-success u-flex u-justify-center u-align-items-center">
                    <i class="fa fa-info u-text-large u-color-white"></i>
                </span>
            </span>

        </span>
        <div class="o-media__body">
            <h6 class="u-mb-zero">Tidak ada Notifikasi</h6>
            <p class="u-text-mute">Situs Berjalan dengan baik dan tidak ada masalah</p>
        </div>
    </a>
</div>