<?php  
include "limit.php";
include "session.php";
include "i.function.php";
include "function.php";
include "timezone.php";
include "mysql.php";

$settings['title'] = 'License Template';
$settings['desc'] = 'Alat Sederhana Membuat Sistem License untuk blogger';
$settings['author'] = 'Kurteyki Ft. Riedayme';
$settings['version'] = 'v1.0';
$baseurl = home_base_url();

//ob_start("sanitize_output");
?>