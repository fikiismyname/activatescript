<?php  
ini_set('max_execution_time', 0);
ini_set('memory_limit', '-1');
set_time_limit(0);
?>